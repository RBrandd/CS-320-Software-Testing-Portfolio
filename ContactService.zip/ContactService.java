package contact;

import java.util.ArrayList;

public class ContactService {
	
	private List<Contact> contacts = new ArrayList<>();
	
	public void addContact(Contact contact) {
		for(Contact c : contacts) {
			if (c.getContactID().equals(contact.getContactID())) {
				throw new IllegalArgumentException("Contact ID already exists");
			}
		}
		contacts.add(contact);
	}
	public void deleteContact(String contactID) {
		contacts.removeIf(contact -> contact.getContactID().equals(contactID));
	}
	public void updateFirstName(String contactID, String firstName) {
		Contact contact = findContact(contactID);
		contact.setFirstName(firstName);
	}
	public void updateLastName(String contactID, String lastName) {
		Contact contact = findContact(contactID);
		contact.setLastName(lastName);
	}
	public void updatePhone(String contactID, String phone) {
		Contact contact = findContact(contactID);
		contact.setPhone(phone);
	}
	public void updateAddress(String contactID, String address) {
		Contact contact = findContact(contactID);
		contact.setAddress(address);
	}
	public Contact findContact(String contactID) {
		for(Contact contact : contacts) {
			if (contacts.getContactID().equals(contactID)) {
				return contact;
			}
		}
		throw new IllegalArgumentException("Contact not found");
	}

}