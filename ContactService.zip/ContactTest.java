package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	
	@Test
	void testValidContactCreation() {
		
		Contact contact = new Contact(
				"123",
				"John",
				"Smith",
				"1234567890",
				"123 Main Street"
		);
		
		assertEquals("John", contact.getFirstName());
	}
	
	@Test
	void testContactIDTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"12345678901",
					"John",
					"Smith",
					"1234567890",
					"Address"
			);
		});
	}
	
	@Test
	void testNullFirstName() {
		assertThrows(IllegalArgumentException.class,() -> {
			new Contact(
					"123",
					"null",
					"Smith",
					"1234567890",
					"Address"
			);
		});
	}
	
	@Test
	void testInvalidPhoneNumber() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"123",
					"John",
					"Smith",
					"123",
					"Address"
			);
		});
	}
}