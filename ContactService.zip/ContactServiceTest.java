package contact;

import org.junit.jupiter.api.
test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	
	@Test
	void testAddContact() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact(
				"1",
				"John",
				"Smith",
				"1234567890",
				"Address"
		);
		
		service.addContact(contact);
		
		assertEquals(
				"John"
				service.findContact("1").getFirstName()
		);
	}
	
	@Test
	void testDuplicateContactID() {
		ContactService service = new ContactService();
		
		Contact contact1 = new Contact(
				"1",
				"John",
				"Smith",
				"1234567890",
				"Address"
		);
		
		Contact contact2 = new Contact(
				"1",
				"Jane",
				"Doe",
				"1234567890",
				"Address"
		);
		
		service.addContact(contact1);;
		
		assertThrows(
				IllegalArgumentException.class,
				() -> service.addContact(contact2)
		);
	}
	
	@Test
	void testDeleteContact() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact(
				"1",
				"John",
				"Smith",
				"1234567890",
				"Address"
		);
		
		service.addContact(contact);;
		service.deleteContact("1");
		
		assertThrows(
				IllegalArgumentException.class,
				() -> service.findContact("1")
		);
	}
	
	

	@Test
	void testUpdateContact() {
	
		ContactService service = new ContactService();
	
		Contact contact = new Contact(
				"1",
				"John",
				"Smith",
				"1234567890"
				"Address"
		);
	
		service.addContact(contact);
		service.updateFirstName("1",  "Bob"));
	
		assertEquals(
				"Bob",
				service.findContact("1".getFirstName()
		);
	}			
}